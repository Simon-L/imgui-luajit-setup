local lovetoSDL = {}
lovetoSDL["4"] = 33
lovetoSDL["f9"] = 66
lovetoSDL["."] = 55
lovetoSDL["kpa"] = 188
lovetoSDL["kp!"] = 207
lovetoSDL["audiostop"] = 260
lovetoSDL["clearagain"] = 162
lovetoSDL["kp3"] = 91
lovetoSDL["r"] = 21
lovetoSDL["lshift"] = 225
lovetoSDL["t"] = 23
lovetoSDL["8"] = 37
lovetoSDL["copy"] = 124
lovetoSDL["6"] = 35
lovetoSDL["unknown"] = 0
lovetoSDL["f14"] = 105
lovetoSDL["kp2"] = 90
lovetoSDL["lang7"] = 150
lovetoSDL["sleep"] = 282
lovetoSDL["find"] = 126
lovetoSDL["kp/"] = 84
lovetoSDL["help"] = 117
lovetoSDL["v"] = 25
lovetoSDL["app2"] = 284
lovetoSDL["kp9"] = 97
lovetoSDL["app1"] = 283
lovetoSDL["kpmem-"] = 212
lovetoSDL["eject"] = 281
lovetoSDL["kptab"] = 186
lovetoSDL["application"] = 101
lovetoSDL["]"] = 48
lovetoSDL["z"] = 29
lovetoSDL["insert"] = 73
lovetoSDL["kpmemstore"] = 208
lovetoSDL["execute"] = 116
lovetoSDL["kbdillumdown"] = 279
lovetoSDL["mute"] = 127
lovetoSDL["kbdillumtoggle"] = 278
lovetoSDL["displayswitch"] = 277
lovetoSDL["brightnessup"] = 276
lovetoSDL["alterase"] = 153
lovetoSDL["kp@"] = 206
lovetoSDL["kp8"] = 96
lovetoSDL["f21"] = 112
lovetoSDL["kp+-"] = 215
lovetoSDL["acbookmarks"] = 274
lovetoSDL["pagedown"] = 78
lovetoSDL["a"] = 4
lovetoSDL["acback"] = 270
lovetoSDL["acrefresh"] = 273
lovetoSDL["tab"] = 43
lovetoSDL["audiomute"] = 262
lovetoSDL["lang8"] = 151
lovetoSDL["www"] = 264
lovetoSDL["kpe"] = 192
lovetoSDL["c"] = 6
lovetoSDL["'"] = 52
lovetoSDL["delete"] = 76
lovetoSDL["left"] = 80
lovetoSDL["acforward"] = 271
lovetoSDL["achome"] = 269
lovetoSDL["acsearch"] = 268
lovetoSDL["lang9"] = 152
lovetoSDL["computer"] = 267
lovetoSDL["e"] = 8
lovetoSDL["f20"] = 111
lovetoSDL["kp00"] = 176
lovetoSDL["calculator"] = 266
lovetoSDL["mail"] = 265
lovetoSDL["kpenter"] = 88
lovetoSDL["acstop"] = 272
lovetoSDL["mediaselect"] = 263
lovetoSDL["f18"] = 109
lovetoSDL["audioplay"] = 261
lovetoSDL["kp."] = 99
lovetoSDL["f23"] = 114
lovetoSDL["lang4"] = 147
lovetoSDL["kpclearentry"] = 217
lovetoSDL["audioprev"] = 259
lovetoSDL["audionext"] = 258
lovetoSDL["mode"] = 257
lovetoSDL["stop"] = 120
lovetoSDL["-"] = 45
lovetoSDL["rgui"] = 231
lovetoSDL["ralt"] = 230
lovetoSDL["numlock"] = 83
lovetoSDL["f19"] = 110
lovetoSDL["kp5"] = 93
lovetoSDL["f6"] = 63
lovetoSDL["k"] = 14
lovetoSDL["menu"] = 118
lovetoSDL["rshift"] = 229
lovetoSDL["kp+"] = 87
lovetoSDL["f22"] = 113
lovetoSDL["rctrl"] = 228
lovetoSDL["kp&&"] = 200
lovetoSDL["lalt"] = 226
lovetoSDL["international6"] = 140
lovetoSDL["m"] = 16
lovetoSDL["1"] = 30
lovetoSDL["kphex"] = 221
lovetoSDL["pageup"] = 75
lovetoSDL["kpdecimal"] = 220
lovetoSDL["prior"] = 157
lovetoSDL["kpd"] = 191
lovetoSDL["n"] = 17
lovetoSDL["kp4"] = 92
lovetoSDL["select"] = 119
lovetoSDL["scrolllock"] = 71
lovetoSDL["brightnessdown"] = 275
lovetoSDL["f8"] = 65
lovetoSDL["end"] = 77
lovetoSDL["kpmem/"] = 214
lovetoSDL["kpmemclear"] = 210
lovetoSDL["kpmem*"] = 213
lovetoSDL["q"] = 20
lovetoSDL["5"] = 34
lovetoSDL["kpmem+"] = 211
lovetoSDL["power"] = 102
lovetoSDL["kp "] = 205
lovetoSDL["kp)"] = 183
lovetoSDL["f24"] = 115
lovetoSDL["nonusbackslash"] = 100
lovetoSDL["s"] = 22
lovetoSDL["7"] = 36
lovetoSDL["separator"] = 159
lovetoSDL["printscreen"] = 70
lovetoSDL["kp:"] = 203
lovetoSDL["undo"] = 122
lovetoSDL["kp||"] = 202
lovetoSDL["kp|"] = 201
lovetoSDL["lgui"] = 227
lovetoSDL["volumeup"] = 128
lovetoSDL["9"] = 38
lovetoSDL["o"] = 18
lovetoSDL["kp>"] = 198
lovetoSDL["return2"] = 158
lovetoSDL["paste"] = 125
lovetoSDL["kp*"] = 85
lovetoSDL["backspace"] = 42
lovetoSDL["w"] = 26
lovetoSDL[";"] = 51
lovetoSDL["kp<"] = 197
lovetoSDL["international3"] = 137
lovetoSDL["lang2"] = 145
lovetoSDL["kpower"] = 195
lovetoSDL["lang6"] = 149
lovetoSDL["kpf"] = 193
lovetoSDL["/"] = 56
lovetoSDL["y"] = 28
lovetoSDL["="] = 46
lovetoSDL["kp1"] = 89
lovetoSDL["international9"] = 143
lovetoSDL["kpb"] = 189
lovetoSDL["kpbackspace"] = 187
lovetoSDL["\\"] = 49
lovetoSDL["return"] = 40
lovetoSDL["kbdillumup"] = 280
lovetoSDL["kp}"] = 185
lovetoSDL["space"] = 44
lovetoSDL["kp{"] = 184
lovetoSDL["kp("] = 182
lovetoSDL["currencysubunit"] = 181
lovetoSDL["kp7"] = 95
lovetoSDL["currencyunit"] = 180
lovetoSDL["decimalseparator"] = 179
lovetoSDL["x"] = 27
lovetoSDL["kp000"] = 177
lovetoSDL["cut"] = 123
lovetoSDL["kp0"] = 98
lovetoSDL["home"] = 74
lovetoSDL["exsel"] = 164
lovetoSDL["`"] = 53
lovetoSDL["international2"] = 136
lovetoSDL["crsel"] = 163
lovetoSDL["clear"] = 156
lovetoSDL["f4"] = 61
lovetoSDL["out"] = 160
lovetoSDL["kpoctal"] = 219
lovetoSDL["cancel"] = 155
lovetoSDL["sysreq"] = 154
lovetoSDL["kpxor"] = 194
lovetoSDL["lang5"] = 148
lovetoSDL["lang3"] = 146
lovetoSDL["kp%"] = 196
lovetoSDL["b"] = 5
lovetoSDL["again"] = 121
lovetoSDL["lang1"] = 144
lovetoSDL["nonus#"] = 50
lovetoSDL["d"] = 7
lovetoSDL["capslock"] = 57
lovetoSDL["lctrl"] = 224
lovetoSDL["down"] = 81
lovetoSDL["international4"] = 138
lovetoSDL["f15"] = 106
lovetoSDL["kp=400"] = 134
lovetoSDL["u"] = 24
lovetoSDL["f12"] = 69
lovetoSDL["international8"] = 142
lovetoSDL["3"] = 32
lovetoSDL["f1"] = 58
lovetoSDL["kp6"] = 94
lovetoSDL["kp&"] = 199
lovetoSDL["["] = 47
lovetoSDL["volumedown"] = 129
lovetoSDL["f10"] = 67
lovetoSDL["h"] = 11
lovetoSDL[","] = 54
lovetoSDL["kp-"] = 86
lovetoSDL["right"] = 79
lovetoSDL["f"] = 9
lovetoSDL["j"] = 13
lovetoSDL["f3"] = 60
lovetoSDL["f5"] = 62
lovetoSDL["f11"] = 68
lovetoSDL["pause"] = 72
lovetoSDL["kp="] = 103
lovetoSDL["i"] = 12
lovetoSDL["kpc"] = 190
lovetoSDL["f7"] = 64
lovetoSDL["kp#"] = 204
lovetoSDL["kpclear"] = 216
lovetoSDL["oper"] = 161
lovetoSDL["l"] = 15
lovetoSDL["0"] = 39
lovetoSDL["f2"] = 59
lovetoSDL["g"] = 10
lovetoSDL["international5"] = 139
lovetoSDL["up"] = 82
lovetoSDL["escape"] = 41
lovetoSDL["kpbinary"] = 218
lovetoSDL["international7"] = 141
lovetoSDL["f16"] = 107
lovetoSDL["f13"] = 104
lovetoSDL["kp,"] = 133
lovetoSDL["international1"] = 135
lovetoSDL["f17"] = 108
lovetoSDL["2"] = 31
lovetoSDL["kpmemrecall"] = 209
lovetoSDL["thsousandsseparator"] = 178
lovetoSDL["p"] = 19

local ffi = require"ffi"
ffi.cdef[[
typedef struct SDL_Window SDL_Window;
SDL_Window *SDL_GL_GetCurrentWindow(void);
void* SDL_GL_GetCurrentContext(void);
int SDL_GL_MakeCurrent(SDL_Window* window,void* context);
]]
local sdl = jit.os == "Windows" and ffi.load("SDL2") or ffi.C

local ig = require "imgui.sdl"
ig.has_imgui_viewport = pcall(function() return ig.lib.ImGuiConfigFlags_ViewportsEnable end)

local function MainDockSpace()
    if not ig.has_imgui_viewport then return end
    if (bit.band(ig.GetIO().ConfigFlags , ig.lib.ImGuiConfigFlags_DockingEnable)==0) then return end
    
    local dockspace_flags = bit.bor(ig.lib.ImGuiDockNodeFlags_NoDockingInCentralNode, ig.lib.ImGuiDockNodeFlags_AutoHideTabBar, ig.lib.ImGuiDockNodeFlags_PassthruCentralNode, ig.lib.ImGuiDockNodeFlags_NoTabBar, ig.lib.ImGuiDockNodeFlags_HiddenTabBar) --ImGuiDockNodeFlags_NoSplit
    ig.DockSpaceOverViewport(nil, dockspace_flags);
end

local function update_key(scancodestr, pressed)
    --print("scancode",scancode)
    local scancode = lovetoSDL[scancodestr]
    if not (scancode >= 0 and scancode < 512) then
        print("scancode",scancode)
    end
    local io = ig.GetIO()

    io.KeysDown[scancode] = pressed
    io.KeyShift = love.keyboard.isDown("rshift") or love.keyboard.isDown("lshift")
    io.KeyCtrl = love.keyboard.isDown("rctrl") or love.keyboard.isDown("lctrl")
    io.KeyAlt = love.keyboard.isDown("ralt") or love.keyboard.isDown("lalt")
    io.KeySuper = ffi.os=="Windows" and false or (love.keyboard.isDown("rgui") or love.keyboard.isDown("lgui"))
end

ig.love_load = function(args)
    local args = args or {}
    local sdlwindow = sdl.SDL_GL_GetCurrentWindow()
    local openglctx = sdl.SDL_GL_GetCurrentContext()
    local instance = ig.Imgui_Impl_SDL_opengl3()
    local igio = ig.GetIO()
    igio.ConfigFlags = ig.lib.ImGuiConfigFlags_NavEnableKeyboard + igio.ConfigFlags
    if ig.has_imgui_viewport then
        if args.use_imgui_docking then
        igio.ConfigFlags = igio.ConfigFlags + ig.lib.ImGuiConfigFlags_DockingEnable
        end
        if args.use_imgui_viewport then
            instance.use_imgui_viewport = true
            igio.ConfigFlags = igio.ConfigFlags + ig.lib.ImGuiConfigFlags_ViewportsEnable
            local oldrender = instance.Render
            instance.Render = function(self)
                oldrender(self)
                local igio = ig.GetIO()
                if bit.band(igio.ConfigFlags , ig.lib.ImGuiConfigFlags_ViewportsEnable) ~= 0 then
                    ig.UpdatePlatformWindows();
                    ig.RenderPlatformWindowsDefault();
                    sdl.SDL_GL_MakeCurrent(sdlwindow,openglctx)
                end
            end
        end
    end
    instance:Init(sdlwindow, openglctx)
    instance.update_key = update_key
    instance.MainDockSpace = MainDockSpace
    instance.textinput = function(text)
        ig.GetIO():AddInputCharactersUTF8(text)
    end
    instance.wheelmoved = function(x,y)
        local ioig = ig.GetIO()
        if x > 0 then
            ioig.MouseWheelH = ioig.MouseWheelH + 1
        elseif x < 0 then
            ioig.MouseWheelH = ioig.MouseWheelH - 1
        end
        if y > 0 then
            ioig.MouseWheel = ioig.MouseWheel + 1
        elseif y < 0 then
            ioig.MouseWheel = ioig.MouseWheel - 1
        end
    end
    return instance
end

return ig
return 'posix for ' .. _VERSION .. ' / luaposix 36.2.1'

-- LuaRocks configuration

rocks_trees = {
   { name = "user", root = home .. "/.luarocks" };
   { name = "system", root = "/home/xox/Programmation/imgui-luajit-setup/lua.wEc9/.lenv" };
}
lua_interpreter = "lua";
variables = {
   LUA_DIR = "/home/xox/Programmation/imgui-luajit-setup/lua.wEc9/.lenv";
   LUA_BINDIR = "/home/xox/Programmation/imgui-luajit-setup/lua.wEc9/.lenv/bin";
}
